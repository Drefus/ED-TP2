#include "Escalonador.hpp"

void Escalonador::Insert(Evento event)
{
    data[tam] = event;
    tam++;
    HeapifyPorCima(tam - 1);
}

Evento Escalonador::Remove()
{
    Evento menorNumero = data[0];
    data[0] = data[tam - 1];
    tam--;
    HeapifyPorBaixo(0);
    return menorNumero;
}

bool Escalonador::IsEmpty()
{
    if (tam > 0)
    {
        return false;
    }
    return true;
}

int Escalonador::GetAncestral(int posicao)
{
    return (posicao - 1) / 2;
}

int Escalonador::GetSucessorEsq(int posicao)
{
    return 2 * posicao + 1;
}

int Escalonador::GetSucessorDir(int posicao)
{
    return 2 * posicao + 2;
}

void Escalonador::HeapifyPorBaixo(int posicao)
{
    int sucessorEsq = GetSucessorEsq(posicao);
    int sucessorDir = GetSucessorDir(posicao);
    int menor = posicao;
    if (sucessorEsq < tam && data[posicao].getTime().compareTime(data[sucessorEsq].getTime()))
    {
        menor = sucessorEsq;
    }
    if (sucessorDir < tam && data[menor].getTime().compareTime(data[sucessorDir].getTime()))
    {
        menor = sucessorDir;
    }
    if (menor != posicao)
    {
        Evento temp = data[posicao];
        data[posicao] = data[menor];
        data[menor] = temp;
        HeapifyPorBaixo(menor);
    }
}

void Escalonador::HeapifyPorCima(int posicao)
{
    int ancestral = GetAncestral(posicao);
    if (data[ancestral].getTime().compareTime(data[posicao].getTime()))
    {
        Evento temp = data[posicao];
        data[posicao] = data[ancestral];
        data[ancestral] = temp;
        HeapifyPorCima(ancestral);
    }
}

Escalonador::Escalonador(int maxsize)
{
    this->data = new Evento[maxsize];
    this->tam = 0;
}

Escalonador::Escalonador() : tam(0), maxsize(0), data(nullptr)
{
}

Escalonador::~Escalonador()
{
}

Evento Escalonador::RemoveById(string id)
{
    for (int i = 0; i < tam; i++)
    {
        if (data[i].getPacienteId() == id)
        {
            Evento menorNumero = data[i];
            data[i] = data[tam - 1];
            tam--;
            HeapifyPorBaixo(i);
            return menorNumero;
        }
    }
    return Evento();
}

Evento Escalonador::GetById(string id)
{
    for (int i = 0; i < tam; i++)
    {
        if (data[i].getPacienteId() == id)
        {
            return data[i];
        }
    }
    return Evento();
}